import requests
# class ApiClient:
#     def get_request(self, url, add_default_header=False, auth_token=None, **kwargs):
#         headers['Content-Type'] = 'application/json'
#         response = requests.get(url, headers=headers)


